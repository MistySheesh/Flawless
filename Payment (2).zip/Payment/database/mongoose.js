const mongoose = require('mongoose');
const config = require("../config.json");

module.exports = {
    init: () => {
        const dbOptions = {
            keepAlive: true,
            useNewUrlParser: true,
            useUnifiedTopology: true,
            autoIndex: false,
            poolSize: 5,
            connectTimeoutMS: 10000,
            family: 4
        };

        mongoose.connect(`mongodb+srv://bot:${config.PASS}@discordbot.qeawj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`, dbOptions);
        mongoose.set('useFindAndModify', false);
        mongoose.Promise = global.Promise;

        mongoose.connection.on('connected', () => {
            console.log(`I have connected to the database succesfully!`);
        });

        mongoose.connection.on('disconnected', () => {
            console.log(`I have disconnected from the database!`);
        });

        mongoose.connection.on('err', (err) => {
            console.log('There was an error with the connection to the database: ' + err);
        });
    }
};
