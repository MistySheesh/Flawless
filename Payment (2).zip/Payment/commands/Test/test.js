module.exports = {
    name: "test",
    aliases: ['t'],
    async execute(message, args, client) {
        message.reply("Test Command Works!")
    },
};