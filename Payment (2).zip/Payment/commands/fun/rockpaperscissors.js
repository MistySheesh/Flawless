module.exports = {
  name: "rockpaperscissors",
  aliases: ["rps"],
  async execute(message, args, client) {
    const botChoice = Math.floor(Math.random() * 2) + 1 //random number beetween 1 and 3.
    let botEmoji;
    let playerEmoji;
    let botChoiceStr;

    if (!args[0]) return message.channel.send('You need to state your choice, Rock, Paper or Scissors');
    if (!['rock', 'paper', 'scissors'].includes(args[0])) return message.channel.send('Your choice was not one of the options: Rock, Paper or Scissors');

    if (botChoice == 1) {
      botChoiceStr = 'rock';
      botEmoji = ':rock: rock';
    }
    if (botChoice == 2) {
      botChoiceStr = 'paper';
      botEmoji = ':newspaper: paper';
    }
    if (botChoice == 3) {
      botChoiceStr = 'scissors';
      botEmoji = ':scissors: scissors';
    }

    if (args[0] == 'rock') playerEmoji = ':rock:';
    if (args[0] == 'paper') playerEmoji = ':newspaper:';
    if (args[0] == 'scissors') playerEmoji = ':scissors:';
    console.log(botChoice)
    console.log(botEmoji);

    if (botChoiceStr == args[0]) return message.channel.send(`I picked: ${botEmoji}, You picked ${playerEmoji}. We tied!`);
    if (args[0] == 'rock') {
      if (botChoiceStr == 'paper') return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You lost!`);
      else return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You won!`);
    } else if (args[0] == 'paper') {
      if (botChoiceStr == 'scissors') return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You lost!`);
      else return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You won!`);
    } else if (args[0] == 'scissors') {
      if (botChoiceStr == 'rock') return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You lost!`);
      else return message.channel.send(`I picked ${botEmoji}, You picked ${playerEmoji}. You won!`);
    }
  },
};