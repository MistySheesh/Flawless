module.exports = {
  name: "pie",
  async execute(message, args, client) {
    message.channel.send('This is a pie! https://cdn.discordapp.com/attachments/831756470109732905/832095579659698206/2Q.png');
  },
};