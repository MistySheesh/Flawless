const Discord = require('discord.js');
 
module.exports = {
  name: "suggest",
  aliases: ["suggestion"],
  async execute(message, args) {
    let suggestion = args.join(' ');
    if (!args[0]) return message.channel.send('You must state something to suggest.');
    const embed = new Discord.MessageEmbed()
      .setTitle(`suggestion`)
      .addField(`suggestion ${suggestion}`, `This was suggested by ${message.author.tag}.`);

    message.channel.send(embed).then(sentMessage => sentMessage.react('👍')).then(reaction => reaction.message.react('👎'));
  },
};