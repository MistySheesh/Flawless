module.exports = {
    name: "verify",
    async execute(message, args, client) {
      if (!message.guild.me.hasPermission("MANAGE_ROLES")) return message.channel.send("I require \`MANAGE_ROLES\` permission.");

      const roles = message.guild.roles.cache.get('')  

      await message.member.roles.add(roles.id).catch(err => console.log(err));

      await message.member.roles.add(roles2.id).catch(err => console.log(err));

      await message.member.roles.add(roles3.id).catch(err => console.log(err));

      await message.member.roles.add(roles4.id).catch(err => console.log(err));

      message.delete()
    },
  };