const Discord = require('discord.js');

module.exports = {
  name: "help",
  async execute(message, args, client) {
    const sectionEmbed = new Discord.MessageEmbed()
   .setTitle('Bot Help Sections')
   .setDescription('Use -help sectionName to access another section.\nSections:\ninformation\nfun\nmoderation\ntool')
   .addField('Fun Commands', 'Commands that all users can user that are for fun and have no purpose.')
   .addField('Leveling', 'Shows Commands for Bot Leveling System.')
   .addField('Information commands', 'Commands that return some form of important imformation.')
   .addField('Moderation commands', 'Commands that are for moderation purposes within a server.')
   .addField('Tool commands', 'Commands that add features to a server.')
   .setFooter(client.user.tag, client.user.displayAvatarURL());
 
const infoEmbed = new Discord.MessageEmbed()  
   .setTitle('Information Commands.')
   .addField('Help Commands', 'This commands shows the user all the commands possable.')
   .addField('Socail Command', 'Displays social media in an embed.');
 
const funEmbed = new Discord.MessageEmbed()
   .setTitle('Fun Commands.')
   .addField('Avatar Command', 'Returns a users avatar.')
   .addField('Meme Commands', 'Returns a Meme to the channel.')
   .addField('Say Command', 'Make the bot say a message to the channel.')
   .addField('suggest', 'Sends your suggestion in a nice embed')
   .addField('gayrate', 'Sends random percentage on how gay you are')
   .addField('straightrate', 'Sends how straight you are!')
   .addField('RPS', 'Plays RPS With you!');
   
 
const moderationEmbed = new Discord.MessageEmbed()
   .setTitle('Moderation Commands.')
   .addField('Ban Command', 'Bans a member from the server')
   .addField('Kick Command', 'Kicks a member from the server')
   .addField('Lock Command', 'Locks a channel in the server')
   .addField('Nuke Command', 'Clones a channel and deletes the old one.')
   .addField('Purge Command', 'Purges messages within a channel')
   .addField('Unban Command', 'Unbans a member from the server')
   .addField('Unlock Command', 'Unlocks a channel in the server')
 
const toolEmbed = new Discord.MessageEmbed()
   .setTitle('Tool Commands.')
   .addField('nickname', 'Changes a members nickname')
   .addField('Verify Command', 'Gives the user the member role for the server.');

   const levelingEmbed = new Discord.MessageEmbed()  
   .setTitle('leveling commands')
   .addField('edit', 'edits users level')
   .addField('leaderboard', 'Shows a leaderboard of people with the top levels in the server')
   .addField('level', 'Shows your Level/Rank in the server');

 
if (!args[0]) return message.channel.send(sectionEmbed);
if (args[0] == 'information') return message.channel.send(infoEmbed);
else if (args[0] == 'fun') return message.channel.send(funEmbed);
else if (args[0] == 'leveling') return message.channel.send(levelingEmbed);
else if (args[0] == 'tool') return message.channel.send(toolEmbed);
else if (args[0] == 'moderation') return message.channel.send(moderationEmbed);
  },
};
