const { MessageButton } = require('discord-buttons');

module.exports = {
  name: "invite",
  async execute(message, args, client) {
    let button = new MessageButton()
    .setStyle('url') 
    .setURL('https://discord.com/api/oauth2/authorize?client_id=845803747782688778&permissions=8&scope=bot')
    .setLabel('Invite') 
    .setID('click_to_function') 
  
  message.channel.send('**Press To Invite me!**', button);
  },
};