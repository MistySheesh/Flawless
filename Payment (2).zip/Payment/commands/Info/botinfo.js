const Discord = require('discord.js');
const moment = require('moment');

module.exports = {
    name: "botinfo",
    aliases: ["clientinfo"],
    cooldown: 5,
    async execute(message, args, client) {
        let usersCount = 0;
        for (const guild of client.guilds.cache) {
            usersCount += (await guild[1].members.fetch()).size
        }

        let Days = Math.floor(client.uptime / 86400000);
        let Hours = Math.floor(client.uptime / 3600000) % 24;
        let Minutes = Math.floor(client.uptime / 60000) % 60;
        let Seconds = Math.floor(client.uptime / 1000) % 60;
        const RemoveUseless = (Duration) => {
            return Duration.replace("0 Day\n", "").replace("0 Hour\n", "").replace("0 Minute\n", "");
        }

        const Developer = client.users.cache.get(client.ownerID)
        let Uptime = await RemoveUseless(`${Days}${Days > 1 ? "d" : "d"} ${Hours}${Hours > 1 ? "h" : "h"} ${Minutes}${Minutes > 1 ? "m" : "m"} ${Seconds}${Seconds > 1 ? "s" : "s"}`);

        const embed = new Discord.MessageEmbed()
            .setTitle(`Client Information`)
            .addField(`Name | ID`, `\`\`\`${client.user.tag}\n${client.user.id}\`\`\``, true)
            .addField(`Client Guild Count`, `\`\`\`${client.guilds.cache.size} Servers\`\`\``, true)
            .addField(`Client User Count`, `\`\`\`${usersCount} Users\`\`\``, true)
            .addField(`Client Channel Count`, `\`\`\`${client.channels.cache.size} Channels\`\`\``, true)
            .addField(`Made Using`, `\`\`\`Discord.js/Node.js/MongoDB\`\`\``, true)
            .addField(`Creation Date`, `\`\`\`${moment.utc(client.user.createdAt).format('DD/MMM/YYYY')}\`\`\``, true)
            .addField(`Bot Ping`, `\`\`\`Latency: ${Date.now() - message.createdTimestamp} ms\nAPI Latency: ${Math.round(client.ws.ping)} ms\`\`\``, true)
            .addField(`Commands Number`, `\`\`\`${client.commands.size} Commands\`\`\``, true)
            .addField(`Prefix`, `\`\`\`${client.prefix}\`\`\``, true)
            .addField(`Uptime`, `\`\`\`${Uptime}\`\`\``, true)
            .addField(`Bot Links`, `Bot Invite [INVITE_HERE]\nSupport/Community Server [SERVER_INVITE_HERE]`)
            .setAuthor(client.user.tag, client.user.displayAvatarURL())
            .setColor(message.guild.me.displayHexColor)
            .setTimestamp();

        message.channel.send(embed)
    },
};