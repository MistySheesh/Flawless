const Discord = require("discord.js");

module.exports = {
    name: 'social',
    aliases: ['links', 'link'],
    description: 'Displays my social medias.',
    async execute(message, args, client) {
        const socialEmbed = new Discord.MessageEmbed()
            .setTitle("My Links/Social Medias.")
            .addField("Twitch: ", "https://www.twitch.tv/miniitsmikey")
            .addField("Discord:", "https://discord.gg/j3sUXSfvBU")
            .setColor("#ff0800")
            .setTimestamp();
        message.channel.send(socialEmbed);

        if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
            message.delete();
        }
    },
};