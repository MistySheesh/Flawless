const Discord = require('discord.js')

module.exports = {
    name: "serverinfo",
    aliases: ['si'],
    async execute(message, args, client) {
        if (!message.guild.available) return;

        /*getting the members with admin*/
        let admins = "";
        message.guild.members.cache.array().forEach(member => {
            if (member.hasPermission("ADMINISTRATOR") && !member.user.bot) {
                admins += member.displayName + ", ";
            }
        });
        admins = admins.slice(0, admins.lastIndexOf(","));

        /*listing the roles in the server*/
        const listedRoles = []
        message.guild.roles.cache.forEach(role => {
            listedRoles.push(role);
        })

        /*listing the emojis in the server*/
        const listedEmojies = [];
        message.guild.emojis.cache.forEach(emoji => {
            listedEmojies.push(emoji);
        })

        let bc = message.guild.premiumSubscriptionCount;
        let bl = message.guild.premiumTier;


        const serverInfo = new Discord.MessageEmbed()
            .setTitle("About " + message.guild.name)
            .addField("Owner", message.guild.owner, true)
            .addField("Nitro Boots", bc ? bc : "None", true)
            .addField("Boost Level", bl ? bl : "0", true)
            .addField("Admin(s)", admins, true)
            .addField("Creation Date", `${message.guild.createdAt.toDateString()} at ${message.guild.createdAt.toLocaleTimeString()}`, true)
            .addField("Channel Count", message.guild.channels.cache.size, true)
            .addField("Member Count", message.guild.members.cache.filter(member => !member.user.bot).size, true)
            .addField("Bot Count", message.guild.members.cache.filter(member => member.user.bot).size, true)
            .addField(`Roles [${listedRoles.length}]`, listedRoles ? listedRoles.join(" | ") : "None")
            .addField(`Emojis [${listedEmojies.length}]`, listedEmojies.length ? listedEmojies.join(", ") : "None")
            .setColor("BLUE")
            .setTimestamp()
            .setFooter(client.user.tag, client.user.displayAvatarURL())

        if (message.guild.icon) {
            await serverInfo.setThumbnail(message.guild.iconURL())
        }


        message.channel.send(serverInfo);

    }
}