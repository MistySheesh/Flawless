const Discord = require('discord.js')

module.exports = {
    name: "userinfo",
    aliases: ['ui'],
    async execute(message, args, client) {
        let target = message.mentions.members.first()
        || message.guild.members.cache.find(member => member.user.username.toLowerCase() == args[0].toLowerCase())
        || message.guild.members.cache.find(user => user.id == args[0]);

    if (!target && args[0])
        return message.channel.send("The member is not in this server");

    if (!args[0])
        target = message.member;

    const rolesList = []

    target.roles.cache.forEach(role => {

        rolesList.push(role);

    })

    const permissions = target.permissions.toArray().map(perm => {
        return perm
            .toLowerCase()
            .replace(/_/g, " ")
            .replace(/\w\S*/g, txt => {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            });
    });

    const { joinedAt, nickname, premiumSince } = target
    const { id, discriminator, bot, createdAt } = target.user

    const userInfo = new Discord.MessageEmbed()
        .setAuthor(`About ${target.user.tag}`)
        .addField("User ID", id, true)
        .addField("Discriminator", discriminator, true)
        .addField("Server Nickname", nickname ? nickname : "None", true)
        .addField("Is Bot", bot, true)
        .addField('Nitro', `${premiumSince ? 'Yes' : 'No'}`, true)
        .addField("Joined At", new Date(joinedAt).toLocaleDateString() + " at " + new Date(joinedAt).toLocaleTimeString())
        .addField("Account Created At", new Date(createdAt).toLocaleDateString() + " at " + new Date(createdAt).toLocaleTimeString())
        .addField(`Roles**[**${rolesList.length}**]**`, rolesList.join(" | "))
        .addField(`Permissions **[**${permissions.length}**]**`, permissions.join(", "))
        .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
        .setColor("BLACK")
        .setTimestamp()
        .setFooter(client.user.tag, client.user.displayAvatarURL());

    message.channel.send(userInfo)

}
}