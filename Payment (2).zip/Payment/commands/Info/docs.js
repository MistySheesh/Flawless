const axios = require("axios");

module.exports = {
    name: "docs",
    aliases: ["d"],
    async execute(message, args, client) {
        if (!args[0]) return message.channel.send("Please give me something to search for.");
            
        const uri = `https://djsdocs.sorta.moe/v2/embed?src=stable&q=${encodeURIComponent(args)}`;
        axios.get(uri)
            .then(embed => {
                const { data } = embed;

                if (data && !data.error) {
                    message.channel.send({ embed: data });
                } else {
                    message.reply("I could not find that search in the documents.");
                };
            }).catch((err) => {
            message.channel.send("Something went wrong.");
        });
    },
};