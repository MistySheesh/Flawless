module.exports = {
  name: "lock",
  async execute(message, args, client) {
    let channel = message.channel
        let everyone = message.guild.roles.everyone
        const everyoneInfo = everyone.permissionsIn(message.channel).serialize();

        if (everyoneInfo.SEND_MESSAGES === false) {
            return message.lineReply("<:unsuccessful:833095044101177384> **|** This channel is already locked")
        }

        try {
            await channel.updateOverwrite(everyone, {
                SEND_MESSAGES: false,
                VIEW_CHANNEL: true
            })

            message.lineReply("<:roles:833196498653151242> This channel has been locked")

        } catch (err) {
            console.log(err)
        }

    }
}