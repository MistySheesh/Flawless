module.exports = {
    name: "clickbutton",
    async execute(button, client) {
        if (button.id === "click_to_function") {
            button.channel.send("Button Works.");
        }
    },
};