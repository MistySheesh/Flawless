const Discord = require('discord.js');
const Levels = require("discord-xp");
const Guild = require("../database/models/guildSchema");
const Afk = require("../database/models/afkSchema");
const mongoose = require("mongoose");

module.exports = {
    name: 'message',
    async execute(message, client) {
        const randomXP = Math.floor(Math.random() * 29) + 1;
        const hasLeveledUP = await Levels.appendXp(message.author.id, message.guild.id, randomXP);
        if (hasLeveledUP) {
            const user = await Levels.fetch(message.author.id, message.guild.id);
            message.channel.send(`🎉 **GG**, ${message.member}, you have leveled up to ${user.level}! 🎉`)
                .then((lvlmsg) => {
                    lvlmsg.delete({ timeout: 3500 });
                });
        };
        if (await Afk.findOne({ userID: message.author.id })) {
            let afkProfile = await Afk.findOne({ userID: message.author.id });
            if (afkProfile.messagesLeft == 0) {
                await Afk.findOneAndDelete({ userID: message.author.id });
                message.channel.send(`You are no longer AFK ${message.author}!`);
            } else {
                await Afk.findOneAndUpdate({ userID: message.author.id }, { messagesLeft: afkProfile.messagesLeft - 1 });
            }
        };
        if (message.mentions.members.first()) {
            await message.mentions.members.forEach(async member => {
                let afkProfile = await Afk.findOne({ userID: member.user.id });
                if (afkProfile) message.channel.send(`That user is AFK because: ${afkProfile.reason}`)
                    .then((afkmsg) => {
                        afkmsg.delete({ timeout: 5000 });
                    });
            });
        };
        let guildProfile = await Guild.findOne({ guildID: message.guild.id });
        if (guildProfile) client.prefix = guildProfile.prefix;

        if (!message.content.startsWith(client.prefix) || message.author.bot) return;

        const args = message.content.slice(client.prefix.length).split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
        if (!command) return;

        if (command.guildOnly && message.channel.type !== 'text') {
            return message.reply('I can\'t execute that command inside DMs!');
        }

        if (command.args && !args.length) {
            let reply = `You didn't provide any arguments, ${message.author}!`;

            if (command.usage) {
                reply += `\nThe proper usage would be: \`${client.prefix}${command.name} ${command.usage}\``;
            }
            return message.channel.send(reply);
        }

        if (!client.cooldowns.has(command.name)) {
            client.cooldowns.set(command.name, new Discord.Collection());
        }

        const now = Date.now();
        const timestamps = client.cooldowns.get(command.name);
        const cooldownAmount = (command.cooldown || 3) * 1000;

        if (timestamps.has(message.author.id)) {
            const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                return message.reply(`please wait ${timeLeft.toFixed(1)} more second(s) before reusing the \`${command.name}\` command.`);
            }
        } else {
            timestamps.set(message.author.id, now);
            setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
            try {
                command.execute(message, args, client);
            } catch (error) {
                console.error(error);
                message.reply('there was an error trying to execute that command!');
            }
        }
    },
};